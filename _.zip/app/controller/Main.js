Ext.define('3725OS.controller.Main', {
    extend: 'Ext.app.Controller'
});